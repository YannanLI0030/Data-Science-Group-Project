# CellLineSelector Final Complete

This is the integrated final-year project release. It contains the raw data,
the dynamic multi-omics recommendation algorithm, the web interface, and the
post-ranking Agent in one directory.

## Quick start

1. On first use, double-click `install_dependencies.bat`.
2. Double-click `start.bat`, or run `start.py` directly.
3. The browser opens `http://127.0.0.1:8000/` automatically.
4. Close the launch window or press `Ctrl+C` in that window to stop the server.

Do not open `web/index.html` directly. The recommendation and evidence
endpoints require the local Python backend. Python 3.9 or later is required.

## Input order

1. Target gene (optional)
2. Target protein (optional; at least one target gene or target protein is required)
3. Exclusion gene (optional)
4. Disease or tissue (required; used as a hard filter)

The system supports three query modes:

- `GENE_MULTIOMICS`: target gene only;
- `PROTEIN_ONLY`: target protein only;
- `COMBINED`: target gene and target protein.

## Scoring rules

`dynamic_cellline_selector_gene_protein.score_candidates()` is the sole ranking
authority. Neither the UI nor the Agent can change its formal ranking, scores,
or recommendation levels.

- Gene and combined modes: RNA has weight 0.55, protein 0.30, and confidence
  0.15. If RNA or protein data are missing, the 0.85 biological component is
  redistributed across the available modalities.
- Protein-only mode: protein has weight 0.85 and confidence 0.15. RNA has zero
  direct scoring weight and contributes only supporting evidence to confidence.
- The exclusion-gene penalty is capped at 0.30.
- Confidence comprises completeness (0.40), source support (0.35), and
  RNA/protein consistency (0.25).
- The miRNA, metabolomics, and global features in Files 12, 13, and 14 provide
  background context only and do not affect ranking.

## Language-model settings

The Model Settings control in the upper-right corner supports:

- offline rule-based explanations, the free default that requires no API;
- the official OpenAI API;
- the official Anthropic API;
- OpenAI-compatible APIs, including DeepSeek, OpenRouter, Ollama, and other
  Chat Completions-compatible services.

The model name, complete API endpoint, and API key can be changed in the UI.
An API key entered in the UI remains in page memory and is sent once to the
local backend at `127.0.0.1`. It is not stored in the HTML, run JSON, CSV output,
or browser storage, and it is cleared when the page is refreshed.

Alternatively, copy `.env.example` to `.env` and set
`OPENAI_API_KEY` or `ANTHROPIC_API_KEY` for the backend. Do not commit or share
an `.env` file that contains real credentials.

Changing the language model affects only the explanatory text. `POST
/api/explain` reads the `run_id` saved by `POST /api/recommend` and verifies the
SHA-256 ranking fingerprint before and after explanation. The Agent has no
ranking component and cannot invoke a separate ranking model.

## Directory structure

```text
CellLineSelector_Final/
├─ start.py / start.bat          # Starts the complete UI by default
├─ install_dependencies.bat
├─ api_server.py                 # Local UI API using the Python standard library
├─ dynamic_cellline_selector_gene_protein.py
├─ web/index.html                # Responsive web interface
├─ src/
│  ├─ data_loader.py
│  ├─ data_merger.py
│  └─ agentic/                   # Explanation and grounding only
├─ data_s3/                      # Raw data files 1–14
├─ gene_cache/
├─ outputs/                      # CSV output
├─ runs/ui/                      # Immutable UI run records
├─ tests/
└─ requirements.txt
```

## Command-line mode

To use the original interactive terminal interface:

```powershell
python start.py --cli
```

For a non-interactive run:

```powershell
python start.py --cli --target_gene EGFR --exclusion_gene ABCB1 `
  --disease "cervical cancer" --non-interactive
```

## Tests

```powershell
python -m unittest discover -s tests -v
```

The tests verify that the Agent cannot change the ranking, that citation and
numeric grounding are enforced, and that protein-only queries use the scoring
boundary `0.85 × protein + 0.15 × confidence`.
